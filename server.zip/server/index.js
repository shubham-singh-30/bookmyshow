const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');
const express = require('express');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'mydb'
});
app.listen(5000,()=>console.log('app listening on 5000'))
// Get all classes
app.get('/classes', (req, res) => {
    connection.query('SELECT * FROM class', (err, results) => {
      if (err) throw err;
      res.json(results);
    });
  });
  
  // Get a class by id
  app.get('/classes/:id', (req, res) => {
    connection.query('SELECT * FROM class WHERE class_id = ?', [req.params.id], (err, results) => {
      if (err) throw err;
      res.json(results[0]);
    });
  });
  
  // Create a new class
  app.post('/classes', (req, res) => {
    const { class_name } = req.body;
    connection.query('INSERT INTO class (class_name) VALUES (?)', [class_name], (err, results) => {
      if (err) throw err;
      res.json({ message: 'Class created successfully' });
    });
  });
  
  // Update a class by id
  app.put('/classes/:id', (req, res) => {
    const { class_name } = req.body;
    connection.query('UPDATE class SET class_name = ? WHERE class_id = ?', [class_name, req.params.id], (err, results) => {
      if (err) throw err;
      res.json({ message: 'Class updated successfully' });
    });
  });
  
  // Delete a class by id
  app.delete('/classes/:id', (req, res) => {
    connection.query('DELETE FROM class WHERE class_id = ?', [req.params.id], (err, results) => {
      if (err) throw err;
      res.json({ message: 'Class deleted successfully' });
    });
  });
  
  // Get all students
  app.get('/students', (req, res) => {
    connection.query('SELECT student.student_id, student.full_name, student.phone_number, student.address, class.class_name FROM student INNER JOIN class ON student.class_id = class.class_id', (err, results) => {
      if (err) throw err;
      res.json(results);
    });
  });
  
 // Get a student by id
app.get('/students/:id', (req, res) => {
    connection.query('SELECT student.student_id, student.full_name, student.phone_number, student.address, class.class_name FROM student INNER JOIN class ON student.class_id = class.class_id WHERE student.student_id = ?', [req.params.id], (err, results) => {
      if (err) throw err;
      res.json(results[0]);
    });
  });
  
  // Create a new student
  app.post('/students', (req, res) => {
    const { full_name, phone_number, address, class_id } = req.body;
    connection.query('INSERT INTO student (full_name, phone_number, address, class_id) VALUES (?, ?, ?, ?)', [full_name, phone_number, address, class_id], (err, results) => {
      if (err) throw err;
      res.json({ message: 'Student created successfully' });
    });
  });
  
  // Update a student by id
  app.put('/students/:id', (req, res) => {
    const { full_name, phone_number, address, class_id } = req.body;
    connection.query('UPDATE student SET full_name = ?, phone_number = ?, address = ?, class_id = ? WHERE student_id = ?', [full_name, phone_number, address, class_id, req.params.id], (err, results) => {
      if (err) throw err;
      res.json({ message: 'Student updated successfully' });
    });
  });
  
  // Delete a student by id
  app.delete('/students/:id', (req, res) => {
    connection.query('DELETE FROM student WHERE student_id = ?', [req.params.id], (err, results) => {
      if (err) throw err;
      res.json({ message: 'Student deleted successfully' });
    });
  });
  
// Get students by class id
app.get('/students/class/:id', (req, res) => {
    connection.query('SELECT * FROM student WHERE class_id = ?', [req.params.id], (err, results) => {
      if (err) throw err;
      res.json(results);
    });
  });

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to database:', err);
  } else {
    console.log('Connected to database');
  }
});